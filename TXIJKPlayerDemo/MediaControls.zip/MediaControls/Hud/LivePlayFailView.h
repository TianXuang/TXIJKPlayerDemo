//
//  LivePlayFailView.h
//  TZInvestment
//
//  Created by yunzhang on 2018/10/23.
//  Copyright © 2018年 TianXuan. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^playRePlayBlock)(UIButton *);
typedef NS_ENUM(NSInteger,liveFailType){
    liveFailType_0,//未直播
    liveFailType_1,//直播开始
    liveFailType_2,//回看内容生成中
    liveFailType_VideoDetail,//视频详情播放错误
    liveFailType_LiveFail,//直播加载失败
    liveFailType_LiveFinish//直播已结束
};
@interface LivePlayFailView : UIView
@property (nonatomic,strong)UILabel * titleLabel;
@property (nonatomic,assign)liveFailType showType;
@property (nonatomic,copy)playRePlayBlock playBlock;
@end
