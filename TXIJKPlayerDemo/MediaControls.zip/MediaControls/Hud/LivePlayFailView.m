//
//  LivePlayFailView.m
//  TZInvestment
//
//  Created by yunzhang on 2018/10/23.
//  Copyright © 2018年 TianXuan. All rights reserved.
//

#import "LivePlayFailView.h"
@interface LivePlayFailView()
@property (nonatomic,strong)UIButton * rebtn;
@end
@implementation LivePlayFailView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.2];
        [self creatUI];
    }
    return self;
}
-(void)creatUI{
    self.titleLabel = [KTFactory creatLabelWithText:@"" fontValue:font750(30) textColor:[UIColor whiteColor] textAlignment:NSTextAlignmentCenter];
    [self addSubview:self.titleLabel];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self);
    }];
    
    UIButton * button =[UIButton buttonWithType:UIButtonTypeCustom];
    [button addTarget:self action:@selector(buttonLoadFailReLoad:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"重新加载" forState:UIControlStateNormal];
    button.layer.borderColor = [UIColor whiteColor].CGColor;
    button.layer.borderWidth = 0.5;
    button.layer.cornerRadius = Anno750(10);
    [button setImage:WSImage(@"播放三角") forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:12];
    [button setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 5)];
    [self addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.titleLabel);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(15);
        make.size.mas_equalTo(CGSizeMake(80, 25));
    }];
    self.rebtn = button;
    
}
-(void)buttonLoadFailReLoad:(UIButton *)btn{
    if (self.playBlock) {
        self.playBlock(btn);
    }
}
- (void)setShowType:(liveFailType)showType{
    if (showType ==liveFailType_0) {
        self.titleLabel.text = @"即将开播，去其他直播间看看吧！";
        self.rebtn.hidden = YES;
    }else if(showType == liveFailType_1){
        self.titleLabel.text = @"直播加载失败，请重新尝试！";
        self.backgroundColor = [UIColor blackColor];
        self.rebtn.hidden = YES;
    }else if(showType == liveFailType_2){
        self.titleLabel.text = @"回看内容生成中！";
        self.rebtn.hidden = YES;
    }else if (showType == liveFailType_VideoDetail){
        self.titleLabel.text = @"视频加载失败";
        self.backgroundColor = [UIColor blackColor];
        self.rebtn.hidden = NO;
    }else if (showType == liveFailType_LiveFail){
        self.titleLabel.text = @"直播加载失败";
        self.backgroundColor = [UIColor blackColor];
        self.rebtn.hidden = NO;
    }else if (showType == liveFailType_LiveFinish){
        self.titleLabel.text = @"直播已结束";
        self.rebtn.hidden = YES;
    }
}
@end
