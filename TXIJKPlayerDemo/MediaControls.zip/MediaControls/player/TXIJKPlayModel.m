//
//  TXIJKPlayModel.m
//  VSFinance
//
//  Created by yunzhang on 2018/12/19.
//  Copyright © 2018年 TianXuan. All rights reserved.
//

#import "TXIJKPlayModel.h"

@implementation TXIJKPlayModel

@end
